export type CategoryType =
  | "Ranks"
  | "Keys"
  | "Kits"
  | "Tags"
  | "Pickaxes"
  | "Upgrade"
  | "Summoners"
  | "Disguises"
  | "Boosters"

export type ServerType = "Factions" | "Prison"

