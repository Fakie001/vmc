export interface TebexUser {
  id: string
  username: string
  minecraft_username: string
  avatar_url?: string
}

